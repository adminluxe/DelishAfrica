import { test, expect } from '@playwright/test';

// Ce test vérifie qu’une page de suivi affiche un marqueur Leaflet
// après réception des événements SSE.

test.describe('Suivi de commande', () => {
  test('affiche un marqueur pour la localisation du coursier', async ({ page }) => {
    // Remplacez l’URL ci-dessous par celle de votre app (localhost:5173 ou votre PWA)
    const orderId = 'demo123';
    await page.goto(`http://localhost:5173/orders/${orderId}/track`);

    // Attendre l’apparition d’un marqueur Leaflet (classe css par défaut)
    const marker = await page.waitForSelector('.leaflet-marker-icon', { timeout: 30000 });
    expect(marker).toBeTruthy();
  });
});