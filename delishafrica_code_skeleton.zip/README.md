# DelishAfrica Code Skeleton

Ce dossier contient des exemples de fichiers pour ajouter un suivi en temps réel dans l’API NestJS, une page de suivi dans l’application React et un script de test Playwright. Vous pouvez copier ces fichiers dans votre monorepo et les adapter à vos chemins et conventions.

## Structure

* `backend/redis.module.ts` – Fournisseur Redis global à injecter dans vos services.
* `backend/couriers.service.ts` – Service pour enregistrer et lire la position des coursiers.
* `backend/couriers.controller.ts` – Endpoint `POST /couriers/:id/location` pour mettre à jour la position.
* `backend/orders.controller.ts` – Endpoint SSE `GET /orders/:id/track` pour diffuser la position et l’état de la commande.
* `backend/orders.module.ts` – Module regroupant les fonctionnalités de suivi des commandes.
* `frontend/TrackOrderPage.tsx` – Composant React/Leaflet affichant la localisation du coursier en temps réel.
* `tests/order-tracking.spec.ts` – Exemple de test Playwright pour vérifier l’affichage d’un marqueur sur la carte.

Adaptez les chemins d’import et l’architecture selon votre projet (par exemple `src/couriers/…`).

Pour exécuter le test Playwright :

```bash
pnpm exec playwright test tests/order-tracking.spec.ts
```

Assurez‑vous de remplacer l’URL dans le fichier `order-tracking.spec.ts` par celle de votre application locale (`http://localhost:5173` ou autre). Le test attend qu’un marqueur Leaflet s’affiche sur la carte.