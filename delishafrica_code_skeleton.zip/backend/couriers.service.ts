import { Injectable, Inject } from '@nestjs/common';
import Redis from 'ioredis';

/**
 * Format de localisation transmis par l’app coursier.
 */
export interface CourierLocation {
  lat: number;
  lng: number;
  accuracy?: number;
  heading?: number;
  speed?: number;
  ts: number; // Timestamp en millisecondes
}

/**
 * Service centralisant la gestion des positions des coursiers.
 * Les positions sont stockées en JSON avec une durée de vie courte (TTL configurable au besoin).
 */
@Injectable()
export class CouriersService {
  constructor(@Inject('REDIS_CLIENT') private readonly redis: Redis) {}

  /**
   * Clé Redis associée à un coursier.
   */
  private key(id: string): string {
    return `courier:loc:${id}`;
  }

  /**
   * Met à jour la position du coursier et définit un TTL (par défaut 60 secondes).
   */
  async updateLocation(id: string, loc: CourierLocation, ttl: number = 60): Promise<void> {
    const key = this.key(id);
    await this.redis.set(key, JSON.stringify(loc), 'EX', ttl);
  }

  /**
   * Retourne la dernière position connue d’un coursier.
   */
  async getLocation(id: string): Promise<CourierLocation | null> {
    const value = await this.redis.get(this.key(id));
    return value ? (JSON.parse(value) as CourierLocation) : null;
  }
}