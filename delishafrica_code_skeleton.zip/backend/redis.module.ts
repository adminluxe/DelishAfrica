import { Module, Global } from '@nestjs/common';
import Redis from 'ioredis';

/**
 * RedisModule fournit un client Redis dans l’ensemble de votre application.
 * Configurez l’URL via la variable d’environnement REDIS_URL ou par défaut `redis://localhost:6379`.
 */
@Global()
@Module({
  providers: [
    {
      provide: 'REDIS_CLIENT',
      useFactory: () => {
        const url = process.env.REDIS_URL ?? 'redis://localhost:6379';
        return new Redis(url);
      },
    },
  ],
  exports: ['REDIS_CLIENT'],
})
export class RedisModule {}