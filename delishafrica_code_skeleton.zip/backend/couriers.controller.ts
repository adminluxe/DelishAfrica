import { Controller, Post, Body, Param, BadRequestException } from '@nestjs/common';
import { CouriersService, CourierLocation } from './couriers.service';

/**
 * Payload attendu pour la mise à jour de localisation.
 */
interface UpdateLocationDto {
  lat: number;
  lng: number;
  accuracy?: number;
  heading?: number;
  speed?: number;
  ts?: number;
}

@Controller('couriers')
export class CouriersController {
  constructor(private readonly couriersService: CouriersService) {}

  /**
   * Endpoint pour mettre à jour la position d’un coursier.
   * Ex : POST /couriers/123/location
   */
  @Post(':id/location')
  async updateLocation(
    @Param('id') id: string,
    @Body() body: UpdateLocationDto,
  ): Promise<{ ok: boolean }> {
    if (typeof body.lat !== 'number' || typeof body.lng !== 'number') {
      throw new BadRequestException('lat and lng are required and must be numbers');
    }
    const payload: CourierLocation = {
      lat: body.lat,
      lng: body.lng,
      accuracy: body.accuracy,
      heading: body.heading,
      speed: body.speed,
      ts: body.ts ?? Date.now(),
    };
    await this.couriersService.updateLocation(id, payload);
    return { ok: true };
  }
}