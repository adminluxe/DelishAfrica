import { Module } from '@nestjs/common';
import { OrdersController } from './orders.controller';

/**
 * Module déclarant le contrôleur SSE pour le suivi des commandes.
 */
@Module({
  controllers: [OrdersController],
})
export class OrdersModule {}