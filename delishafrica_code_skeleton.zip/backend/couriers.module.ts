import { Module } from '@nestjs/common';
import { RedisModule } from './redis.module';
import { CouriersService } from './couriers.service';
import { CouriersController } from './couriers.controller';

/**
 * Module déclarant les endpoints et le service de gestion des coursiers.
 */
@Module({
  imports: [RedisModule],
  controllers: [CouriersController],
  providers: [CouriersService],
  exports: [CouriersService],
})
export class CouriersModule {}