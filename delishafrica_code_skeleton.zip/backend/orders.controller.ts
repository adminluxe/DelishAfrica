import { Controller, Sse, Param, Inject } from '@nestjs/common';
import { interval, Observable, from } from 'rxjs';
import { mergeMap } from 'rxjs/operators';
import Redis from 'ioredis';

interface TrackingEvent {
  orderId: string;
  courierId: string;
  courierLoc: {
    lat: number;
    lng: number;
    ts: number;
    accuracy?: number;
    heading?: number;
    speed?: number;
  } | null;
  status: string;
  eta?: number;
}

@Controller('orders')
export class OrdersController {
  constructor(@Inject('REDIS_CLIENT') private readonly redis: Redis) {}

  /**
   * Stream SSE: diffuse les mises à jour de l’état d’une commande et la position du coursier.
   * Exemple d’URL : GET /orders/abc123/track
   */
  @Sse(':id/track')
  trackOrder(@Param('id') orderId: string): Observable<TrackingEvent> {
    // Dans un vrai cas, on lie orderId -> courierId via la base de données.
    const courierId = orderId;
    return interval(3000).pipe(
      mergeMap(() => {
        const key = `courier:loc:${courierId}`;
        return from(this.redis.get(key).then(locStr => {
          const loc = locStr ? JSON.parse(locStr) : null;
          const status = loc ? 'en_route' : 'waiting';
          return {
            orderId,
            courierId,
            courierLoc: loc,
            status,
            eta: undefined,
          } as TrackingEvent;
        }));
      }),
    );
  }
}