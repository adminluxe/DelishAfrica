import React, { useEffect, useState } from 'react';
import { MapContainer, TileLayer, Marker, Popup } from 'react-leaflet';
import L from 'leaflet';

interface TrackingEvent {
  orderId: string;
  courierId: string;
  courierLoc: {
    lat: number;
    lng: number;
    ts: number;
    accuracy?: number;
    heading?: number;
    speed?: number;
  } | null;
  status: string;
  eta?: number;
}

interface Props {
  orderId: string;
}

const defaultPosition: [number, number] = [50.8467, 4.3525];

// Fix Leaflet's default icon (otherwise markers may not appear)
const DefaultIcon = L.icon({
  iconUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png',
  shadowUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png',
  iconSize: [25, 41],
  iconAnchor: [12, 41],
});
L.Marker.prototype.options.icon = DefaultIcon;

const TrackOrderPage: React.FC<Props> = ({ orderId }) => {
  const [tracking, setTracking] = useState<TrackingEvent | null>(null);

  useEffect(() => {
    const es = new EventSource(`/orders/${orderId}/track`);
    es.onmessage = event => {
      try {
        const data: TrackingEvent = JSON.parse(event.data);
        setTracking(data);
      } catch (err) {
        console.error('Erreur de parsing SSE:', err);
      }
    };
    es.onerror = err => {
      console.error('Erreur SSE', err);
    };
    return () => {
      es.close();
    };
  }, [orderId]);

  const position = tracking?.courierLoc
    ? [tracking.courierLoc.lat, tracking.courierLoc.lng] as [number, number]
    : defaultPosition;

  return (
    <div className="p-4 space-y-4">
      <h1 className="text-2xl font-bold">Suivi de la commande #{orderId}</h1>
      <p>Status : <strong>{tracking?.status ?? 'chargement...'}</strong></p>
      {tracking?.eta && <p>Temps estimé : {tracking.eta} min</p>}
      <MapContainer center={position} zoom={13} style={{ height: '60vh', width: '100%' }}>
        <TileLayer
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
          attribution='&copy; OpenStreetMap contributors'
        />
        {tracking?.courierLoc && (
          <Marker position={[tracking.courierLoc.lat, tracking.courierLoc.lng]}>
            <Popup>Mise à jour: {new Date(tracking.courierLoc.ts).toLocaleTimeString()}</Popup>
          </Marker>
        )}
      </MapContainer>
    </div>
  );
};

export default TrackOrderPage;