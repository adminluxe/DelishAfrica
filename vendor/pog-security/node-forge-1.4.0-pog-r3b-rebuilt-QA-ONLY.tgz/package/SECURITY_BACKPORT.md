# OrchidPay private security backport

Original package name and version are retained for advisory visibility. This is not an official upstream release. No Store or live-payment approval.

Original node-forge LICENSE is preserved byte-for-byte (BSD-3-Clause OR GPL-2.0). RSA fix: digitalbazaar/forge PR1160 commit 889cee0901659df2379f4153be322a45c6f202b5, building on PR1152 and the canonicalization approach of PR1159. Browser bundles rebuilt twice from fully pinned builder dependencies.

## POG R3 laboratory-only DER hardening (21 October 2026)
R3 is derived from the pinned OrchidPay B7-C/R2 package and preserves the original
npm name/version (node-forge 1.4.0). Full DER byte equality is enforced when
_parseAllDigestBytes=false; this intentionally tightens the legacy internal
testing option. No claim of official upstream remediation or external review.
Only a deterministic untrusted QA tarball is produced. LICENSE is unchanged.
Do not merge, publish, sign binaries or enable financial LIVE.

## POG R3B deterministic browser distribution QA (21 October 2026)
Source: official forge v1.4.0 tag fa385f92440879601240020f158bed68e444e83a.
Builder: pinned npm lock SHA256 45f26db2fb3169e40f5ca197d9bc5eaa26f211e17b6f927b8b055042418e5b3f.
Two clean installs with lifecycle scripts disabled; both minified Forge
bundles and their sourcemaps generated offline twice, byte-identical.
Browser-VM SHA-256, SHA-384, SHA-512 strict DER negatives passed against
lib/index.js and the core/all distributions. No live signing credentials.
Testing is targeted QA, not independent security or store certification.
Same upstream name/version retained; npm advisories stay visible.
Keep QA private; no Store, npm publish, PSP LIVE, merge, or signed binary.
