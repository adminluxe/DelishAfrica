# OrchidPay private security backport

Original package name and version are retained for advisory visibility. This is not an official upstream release. No Store or live-payment approval.

Original node-forge LICENSE is preserved byte-for-byte (BSD-3-Clause OR GPL-2.0). RSA fix: digitalbazaar/forge PR1160 commit 889cee0901659df2379f4153be322a45c6f202b5, building on PR1152 and the canonicalization approach of PR1159. Browser bundles rebuilt twice from fully pinned builder dependencies.
