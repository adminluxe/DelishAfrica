# OrchidPay private security backport

Original package name and version are retained for advisory visibility. This is not an official upstream release. No Store or live-payment approval.

Original braces MIT LICENSE is preserved byte-for-byte. Adapted from upstream PR72 (28d440b5dd449dbf1fe6f3506cf94ecca4d02660), LabTether/watari-dev public backport (https://gist.github.com/watari-dev/1299cb4f19f9362b1a1495d143c7eb00), PEV V3.1 safeguards, and OrchidPay R2 parser/error compatibility corrections. LabTether describes the upstream package as remaining MIT licensed.
