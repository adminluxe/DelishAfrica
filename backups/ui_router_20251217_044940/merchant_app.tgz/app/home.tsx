import React from 'react';
import AppBackground from '../components/AppBackground';
import HeroHeader from '../components/HeroHeader';
import MagicButton from '../components/MagicButton';
import StatusPill from '../components/StatusPill';
import { ScrollView, View, Text, Pressable } from 'react-native';
import { useRouter } from 'expo-router';
import { demoOrders } from '../demoData';

export default function MerchantHome() {
  const router = useRouter();

  const goToOrder = (id: string) => {
    router.push(`/commande/${id}`);
  };

  return (
    <AppBackground app="merchant">
<ScrollView
      style={{ flex: 1, backgroundColor: '#020617' }}
      contentContainerStyle={{
        paddingTop: 40,
        paddingBottom: 32,
        paddingHorizontal: 20,
      }}
    >
      {/* Header */}
      <View style={{ alignItems: 'center', marginBottom: 24 }}>
        <Text
          style={{
            color: '#facc15',
            fontSize: 24,
            fontWeight: '800',
            textAlign: 'center',
          }}
        >
          DelishAfrica – Marchand
        </Text>
        <Text
          style={{
            color: '#e5e7eb',
            fontSize: 14,
            marginTop: 8,
            textAlign: 'center',
          }}
        >
          Vue démo des commandes en temps réel dans votre restaurant.
        </Text>
      </View>

      {/* Résumé */}
      <View
        style={{
          backgroundColor: '#020617',
          borderRadius: 20,
          padding: 16,
          borderWidth: 1,
          borderColor: '#111827',
          marginBottom: 20,
        }}
      >
        <Text style={{ color: '#22c55e', fontWeight: '700', marginBottom: 4 }}>
          ● Service en cours (démo)
        </Text>
        <Text style={{ color: '#9ca3af' }}>
          Exemple de 3 commandes actives, avec ETA du coursier et contenu détaillé.
        </Text>
      </View>

      {/* Liste des commandes */}
      <View style={{ marginBottom: 24 }}>
        <Text
          style={{
            color: '#ffffff',
            fontSize: 18,
            fontWeight: '700',
            marginBottom: 8,
          }}
        >
          Commandes en préparation (démo)
        </Text>
        <Text style={{ color: '#9ca3af', marginBottom: 12 }}>
          Exemple de commandes reçues via l&apos;app DelishAfrica – Client.
        </Text>

        {demoOrders.map((order) => (
          <Pressable
            key={order.id}
            onPress={() => goToOrder(order.id)}
            style={{ marginBottom: 12 }}
          >
            <View
              style={{
                backgroundColor: '#020617',
                borderRadius: 18,
                padding: 16,
                borderWidth: 1,
                borderColor: '#111827',
              }}
            >
              <Text
                style={{
                  color: '#ffffff',
                  fontSize: 16,
                  fontWeight: '600',
                  marginBottom: 4,
                }}
              >
                Commande {order.id}
              </Text>
              <Text style={{ color: '#9ca3af', marginBottom: 4 }}>
                Client : {order.customerName}
              </Text>
              <Text style={{ color: '#9ca3af', marginBottom: 6 }}>
                Livraison : {order.address}
              </Text>
              <View
                style={{
                  flexDirection: 'row',
                  justifyContent: 'space-between',
                }}
              >
                <Text style={{ color: '#e5e7eb' }}>{order.etaPickup}</Text>
                <Text style={{ color: '#facc15', fontWeight: '700' }}>
                  {order.total}
                </Text>
              </View>
            </View>
          </Pressable>
        ))}
      </View>
    </ScrollView>
    </AppBackground>
  );
}
