import { Module } from '@nestjs/common';
import { MenuController } from './menu/menu.controller';
import { DemoOrdersController } from './orders/demo-orders.controller';

@Module({
  imports: [],
  controllers: [MenuController, DemoOrdersController],
  providers: [],
})
export class AppModule {}
